from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

# Set up Chrome WebDriver
serv_obj = Service("C:\\webdrivers\\chromedriver.exe")  # Use double backslashes in path
driver = webdriver.Chrome(service=serv_obj)

# Open Swag Labs site
driver.get("https://www.saucedemo.com/")
driver.maximize_window()

# Login steps
driver.find_element(By.ID, "user-name").send_keys("standard_user")
driver.find_element(By.ID, "password").send_keys("secret_sauce")
driver.find_element(By.ID, "login-button").click()

# Verify page title
print(driver.title)
if driver.title == "Swag Labs":
    print("✅ Test Passed")
else:
    print("❌ Test Failed")

# Collect and count all <a> tags
links = driver.find_elements(By.TAG_NAME, "a")
print("No of links are:", len(links))

# Print all link texts
for link in links:
    print(link.text)

# Close browser
driver.close()

